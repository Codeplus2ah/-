
let count = 0;
let tasbeehIndex = 0;
const tasbeehTexts = ["استغفر الله", "سبحان الله", "الحمد لله", "الله أكبر"];

function incrementCounter() {
  count++;
  document.getElementById('counter').textContent = count;
  const tasbeehList = document.getElementById('tasbeehList');
  const li = document.createElement('li');
  li.textContent = tasbeehTexts[tasbeehIndex];
  tasbeehList.appendChild(li);
}

function resetCounter() {
  count = 0;
  document.getElementById('counter').textContent = count;
  document.getElementById('tasbeehList').innerHTML = `
    <li>استغفر الله</li>
    <li>سبحان الله</li>
    <li>الحمد لله</li>
    <li>الله أكبر</li>
  `;
}

function toggleTasbeeh() {
  tasbeehIndex = (tasbeehIndex + 1) % tasbeehTexts.length;
  document.getElementById('tasbeehList').innerHTML = `
    <li>${tasbeehTexts[tasbeehIndex]}</li>
    <li>${tasbeehTexts[(tasbeehIndex + 1) % tasbeehTexts.length]}</li>
    <li>${tasbeehTexts[(tasbeehIndex + 2) % tasbeehTexts.length]}</li>
    <li>${tasbeehTexts[(tasbeehIndex + 3) % tasbeehTexts.length]}</li>
  `;
}